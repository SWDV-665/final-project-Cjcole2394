import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { CombatTrackerProvider } from '../../providers/combat-tracker/combat-tracker';
import { InputDialogServiceProvider } from '../../providers/input-dialog/input-dialog';
//import { SocialSharing } from '@ionic-native/social-sharing/ngx';


@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  title = "Comabt Tracker";

  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public alertCtrl: AlertController, public dataService: CombatTrackerProvider, public inputDialogService: InputDialogServiceProvider) {

  }

  loadItems() {
    return this.dataService.getItems();
  }

  removeItem(item, index) {
    console.log("Removing Item - ", item, index);
    const toast = this.toastCtrl.create({
      message: 'Removing Item - ' + index + " ...",
      duration: 3000
    });
    toast.present();

    this.dataService.removeItem(index);  
  }

  //shareItem(item, index) {
    //console.log("Sharing Item - ", item, index);
    //const toast = this.toastCtrl.create({
      //message: 'Sharing Item - ' + index + " ...",
      //duration: 3000
    //});

    //toast.present();

    //let message = "Grocery Item - Name: " + item.name + " - Quantity: " + item.quantity;
    //let subject = "Shared via Groceries app";

    //this.socialSharing.share(message, subject).then(() => {
      // Sharing via email is possible
      //console.log("Shared successfully!");
    //}).catch((error) => {
      //console.error("Error while sharing ", error);
    //});    

  

  editItem(item, index) {
    console.log("Edit Item - ", item, index);
    const toast = this.toastCtrl.create({
      message: 'Editing Item - ' + index + " ...",
      duration: 3000
    });
    toast.present();
    this.inputDialogService.showPrompt(item, index);
  }  

  addItem() {
    console.log("Adding Item");
    this.inputDialogService.showPrompt();
  }



}
